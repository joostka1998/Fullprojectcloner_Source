export const environment = {
  production: false,
  firebase: {
    apiKey: 'AIzaSyAbdkvK_HB1gqNZ7xoeL8IEEcbmkNyGatQ',
    authDomain: 'fullprojectcloner.firebaseapp.com',
    databaseURL: 'https://fullprojectcloner.firebaseio.com',
    projectId: 'fullprojectcloner',
    storageBucket: 'fullprojectcloner.appspot.com',
    messagingSenderId: '242723023957'}
};
