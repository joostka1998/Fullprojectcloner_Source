import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-sidemenu',
  templateUrl: './sidemenu.component.html',
  styleUrls: ['./sidemenu.component.sass']
})
export class SidemenuComponent implements OnInit {
  currentYear;

  constructor() { }

  ngOnInit() {
    this.currentYear = (new Date()).getFullYear();
  }

}
